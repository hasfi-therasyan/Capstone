package com.example.capstone.model

import com.example.capstone.model.Product

data class ProductList(val data: List<Product>)
