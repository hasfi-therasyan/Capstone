package com.example.capstone.model

import com.example.capstone.model.Book

data class BookList(val data: List<Book>)
