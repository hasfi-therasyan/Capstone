package com.example.capstone.utils

object Constant {
    const val MERCHAT_ID_MIDTRANS = ""
    const val CLIENT_KEY_MIDTRANS = "SB-Mid-client-"
    const val SERVER_KEY_MIDTRANS = "SB-Mid-server-"
    const val BASE_URL_MIDTRANS = "PHP API"

    const val KEY_ID_RAZORAPP = "rzp_test_";
    const val KEY_SECRET_RAZORAPP = "";
}