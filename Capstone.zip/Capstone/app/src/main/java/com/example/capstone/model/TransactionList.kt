package com.example.capstone.model

import com.example.capstone.model.Transaction

data class TransactionList(val data: List<Transaction>)
