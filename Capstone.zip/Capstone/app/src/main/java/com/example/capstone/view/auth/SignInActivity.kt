package com.example.capstone.view.auth

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.capstone.R
import com.example.capstone.view.bottom_nav.BottomNavActivity

class SignInActivity : AppCompatActivity() {

    lateinit var buttonSignIn: Button
    lateinit var buttonLogin: Button
    lateinit var buttonRegister: Button

    lateinit var etEmail: EditText
    lateinit var etPassword: EditText

    companion object {
        private const val RC_SIGN_IN = 1
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_in_old)

        buttonSignIn = findViewById(R.id.buttonSignIn)
        buttonLogin = findViewById(R.id.buttonLogin)
        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        buttonRegister = findViewById(R.id.buttonRegister)

        //
        buttonSignIn.setOnClickListener {
            signIn()
        }

        //
        buttonLogin.setOnClickListener {
            loginUser()
        }

        buttonRegister.setOnClickListener {
            createUser()
        }
    }

    private fun loginUser() {
        val email = etEmail.getText().toString()
        val password = etPassword.getText().toString()

        if (email.isEmpty()) {
            Toast.makeText(this, "Email is cannot be empty", Toast.LENGTH_SHORT).show()
        } else if (password.isEmpty()) {
            Toast.makeText(this, "Password is cannot be empty", Toast.LENGTH_SHORT).show()
        }
    }

    public override fun onStart() {
        super.onStart()
        // Check if user is signed in (non-null) and update UI accordingly.

        val intent = Intent(this, BottomNavActivity::class.java)
        startActivity(intent)

    }

    private fun createUser() {
        val email = etEmail.getText().toString()
        val password = etPassword.getText().toString()

        if (email.isEmpty()) {
            Toast.makeText(this, "Email is cannot be empty", Toast.LENGTH_SHORT).show()
        } else if (password.isEmpty()) {
            Toast.makeText(this, "Password is cannot be empty", Toast.LENGTH_SHORT).show()
        }
    }

    private fun signIn() {
        val signInIntent = googleSignInClient.signInIntent
        startActivityForResult(signInIntent, RC_SIGN_IN)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        // Result returned from launching the Intent from GoogleSignInApi.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            val exception = task.exception

            if (task.isSuccessful) {
                Log.w("SignInActivity", exception.toString())

            }
        }
    }
}